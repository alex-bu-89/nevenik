#!/usr/bin/expect -f

# REMOVE OLD FILES
spawn ssh uvergr0w@uvergr0w.beget.tech
expect "assword:"
send "mZYthCbn\r"
expect "Welcome to LTD BeGet SSH Server 'dozor3'"
send "cd ./kupinevenik.ru/public_html\r"
expect ""
send "rm -rf ./*\r"
expect ""
send "exit\r"
interact

# # BUILD
# spawn bash -c "gulp production"
# interact

# ZIP
spawn bash -c "zip -r archive.zip ./*"
expect ""
interact

# DEPLOY
spawn bash -c "scp -r ./archive.zip uvergr0w@uvergr0w.beget.tech:./kupinevenik.ru/public_html/"
expect "assword:"
send "mZYthCbn\r"
interact

# UNZIP
spawn ssh uvergr0w@uvergr0w.beget.tech
expect "assword:"
send "mZYthCbn\r"
expect "Welcome to LTD BeGet SSH Server 'dozor3'"
send "cd ./kupinevenik.ru/public_html\r"
expect ""
send "unzip archive.zip\r"
expect ""
send "rm archive.zip\r"
expect ""
send "rm wp-config.php\r"
expect ""
send "mv wp-config-prod.php wp-config.php\r"
expect ""
send "exit\r"
interact

# CLEAN
spawn bash -c "rm ./archive.zip\r"
expect ""
interact
